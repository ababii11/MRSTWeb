Install-Package EntityFramework -Version 6.4.4
Update-Package -reinstall 